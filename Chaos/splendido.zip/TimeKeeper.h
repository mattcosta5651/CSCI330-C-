#ifndef TIME_KEEPER_H
#define TIME_KEEPER_H

class TimeKeeper
{
public:
	virtual void tick(long time) = 0;
};


#endif
